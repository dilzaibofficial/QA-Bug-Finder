from flask import Blueprint, request, jsonify
from datetime import datetime
from pathlib import Path
import os, sys, uuid, shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, r"d:\Zainab FYP\model_training")

from db import get_db
import config

upload_bp = Blueprint("upload", __name__)


def _allowed(filename):
    return Path(filename).suffix.lower() in config.ALLOWED_EXT


def _run_analysis(file_path: str, filename: str, analysis_id: str):
    """Run ML predictor on uploaded file and store results in MongoDB."""
    db = get_db()
    db.analysis.update_one({"_id": analysis_id},
                           {"$set": {"status": "processing"}})
    try:
        from predictor import BugPredictor
        predictor = BugPredictor()

        ext = Path(filename).suffix.lower()
        if ext == ".zip":
            raw_bugs = predictor.analyze_zip(file_path)
        else:
            raw_bugs = predictor.analyze_file(file_path)

        # Save each bug to DB
        bugs_inserted = []
        for i, bug in enumerate(raw_bugs, start=1):
            bug_doc = {
                "analysis_id"       : analysis_id,
                "bug_id"            : bug.get("bug_id", f"BUG-{str(i).zfill(3)}"),
                "type"              : bug.get("type", "Logical"),
                "severity"          : bug.get("severity", "Medium"),
                "file"              : bug.get("file", filename),
                "line_number"       : bug.get("line_number", 0),
                "description"       : bug.get("description", ""),
                "ai_reason"         : bug.get("ai_reason", ""),
                "suggested_fix"     : bug.get("suggested_fix", ""),
                "assigned_to"       : bug.get("assigned_to", "Developer"),
                "status"            : "Open",
                "defect_probability": bug.get("defect_probability", 0),
                "type_confidence"   : bug.get("type_confidence", 0),
                "created_at"        : datetime.utcnow().isoformat(),
            }
            r = db.bugs.insert_one(bug_doc)
            bug_doc["_id"] = str(r.inserted_id)
            bugs_inserted.append(bug_doc)

        total    = len(bugs_inserted)
        critical = sum(1 for b in bugs_inserted if b["severity"] == "Critical")

        db.analysis.update_one({"_id": analysis_id}, {"$set": {
            "status"       : "completed",
            "total_bugs"   : total,
            "critical_bugs": critical,
            "end_time"     : datetime.utcnow().isoformat(),
        }})
        return total, critical

    except Exception as e:
        db.analysis.update_one({"_id": analysis_id},
                               {"$set": {"status": "failed", "error": str(e)}})
        raise e


# ── POST /api/upload ─────────────────────────────────────────────────────────
@upload_bp.route("", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file     = request.files["file"]
    user_id  = request.form.get("user_id", "demo_user")

    if not file.filename:
        return jsonify({"error": "Empty filename"}), 400
    if not _allowed(file.filename):
        return jsonify({"error": f"File type not supported. Use: {', '.join(config.ALLOWED_EXT)}"}), 400

    # Save file
    safe_name   = f"{uuid.uuid4().hex}_{file.filename}"
    save_path   = os.path.join(config.UPLOAD_DIR, safe_name)
    file.save(save_path)

    file_size = os.path.getsize(save_path)
    if file_size > config.MAX_FILE_MB * 1024 * 1024:
        os.remove(save_path)
        return jsonify({"error": f"File too large (max {config.MAX_FILE_MB}MB)"}), 413

    db = get_db()
    analysis_id = str(uuid.uuid4())

    # Save upload record
    upload_doc = {
        "user_id"    : user_id,
        "filename"   : file.filename,
        "saved_as"   : safe_name,
        "file_path"  : save_path,
        "file_size"  : file_size,
        "file_type"  : Path(file.filename).suffix.upper().lstrip("."),
        "upload_date": datetime.utcnow().isoformat(),
        "analysis_id": analysis_id,
        "status"     : "uploaded",
    }
    upload_result = db.uploads.insert_one(upload_doc)
    upload_id     = str(upload_result.inserted_id)

    # Create analysis record
    db.analysis.insert_one({
        "_id"         : analysis_id,
        "upload_id"   : upload_id,
        "user_id"     : user_id,
        "filename"    : file.filename,
        "start_time"  : datetime.utcnow().isoformat(),
        "status"      : "queued",
        "total_bugs"  : 0,
        "critical_bugs": 0,
    })

    # Run analysis (synchronous for now)
    try:
        total, critical = _run_analysis(save_path, file.filename, analysis_id)
        progress = 75 if total > 0 else 100

        # Save to history
        db.history.insert_one({
            "user_id"        : user_id,
            "upload_id"      : upload_id,
            "analysis_id"    : analysis_id,
            "filename"       : file.filename,
            "file_type"      : Path(file.filename).suffix.upper().lstrip("."),
            "file_path"      : f"/uploads/{safe_name}",
            "analyzed_on"    : datetime.utcnow().isoformat(),
            "total_bugs"     : total,
            "critical_bugs"  : critical,
            "status"         : "completed",
            "progress"       : progress,
        })

        return jsonify({
            "message"     : "File uploaded and analyzed successfully",
            "upload_id"   : upload_id,
            "analysis_id" : analysis_id,
            "filename"    : file.filename,
            "total_bugs"  : total,
            "critical_bugs": critical,
        }), 200

    except Exception as e:
        return jsonify({"error": f"Analysis failed: {str(e)}"}), 500


# ── GET /api/upload/status/<analysis_id> ─────────────────────────────────────
@upload_bp.route("/status/<analysis_id>", methods=["GET"])
def get_status(analysis_id):
    db  = get_db()
    rec = db.analysis.find_one({"_id": analysis_id})
    if not rec:
        return jsonify({"error": "Analysis not found"}), 404
    rec.pop("_id", None)
    return jsonify(rec), 200
