import os

MONGO_URI   = "mongodb://localhost:27017"
DB_NAME     = "bug_detector"
UPLOAD_DIR  = os.path.join(os.path.dirname(__file__), "uploads")
SECRET_KEY  = "fyp_bug_detector_secret_2026"
MAX_FILE_MB = 50

ALLOWED_EXT = {'.zip', '.java', '.py', '.js', '.ts',
               '.log', '.txt', '.cpp', '.c', '.cs'}

os.makedirs(UPLOAD_DIR, exist_ok=True)
